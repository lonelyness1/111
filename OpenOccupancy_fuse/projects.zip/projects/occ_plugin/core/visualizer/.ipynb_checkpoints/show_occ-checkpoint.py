
# import torch.nn.functional as F
# import torch
# import numpy as np
# from os import path as osp
# import os

# def save_occ(pred_c, pred_f, img_metas, path, visible_mask=None, gt_occ=None, free_id=0, thres_low=0.4, thres_high=0.99):

#     """
#     visualization saving for paper:
#     1. gt
#     2. pred_f pred_c
#     3. gt visible
#     4. pred_f visible
#     """
#     pred_f = F.softmax(pred_f, dim=1)
#     pred_f = pred_f[0].cpu().numpy()  # C W H D
#     pred_c = F.softmax(pred_c, dim=1)
#     pred_c = pred_c[0].cpu().numpy()  # C W H D
#     # visible_mask = visible_mask[0].cpu().numpy().reshape(-1) > 0  # WHD
#     gt_occ = gt_occ.data[0][0].cpu().numpy()  # W H D
#     gt_occ[gt_occ==255] = 0
#     _, W, H, D = pred_f.shape
#     coordinates_3D_f = np.stack(np.meshgrid(np.arange(W), np.arange(H), np.arange(D), indexing='ij'), axis=-1).reshape(-1, 3) # (W*H*D, 3)
#     _, W, H, D = pred_c.shape
#     coordinates_3D_c = np.stack(np.meshgrid(np.arange(W), np.arange(H), np.arange(D), indexing='ij'), axis=-1).reshape(-1, 3) # (W*H*D, 3)
#     pred_f = np.argmax(pred_f, axis=0) # (W, H, D)
#     pred_c = np.argmax(pred_c, axis=0) # (W, H, D)
#     occ_pred_f_mask = (pred_f.reshape(-1))!=free_id
#     occ_pred_c_mask = (pred_c.reshape(-1))!=free_id
#     occ_gt_mask = (gt_occ.reshape(-1))!=free_id
#     pred_f_save = np.concatenate([coordinates_3D_f[occ_pred_f_mask], pred_f.reshape(-1)[occ_pred_f_mask].reshape(-1, 1)], axis=1)[:, [2,1,0,3]]  # zyx cls
#     pred_c_save = np.concatenate([coordinates_3D_c[occ_pred_c_mask], pred_c.reshape(-1)[occ_pred_c_mask].reshape(-1, 1)], axis=1)[:, [2,1,0,3]]  # zyx cls
#     # pred_f_visible_save = np.concatenate([coordinates_3D_f[occ_pred_f_mask&visible_mask], pred_f.reshape(-1)[occ_pred_f_mask&visible_mask].reshape(-1, 1)], axis=1)[:, [2,1,0,3]]  # zyx cls
#     gt_save = np.concatenate([coordinates_3D_f[occ_gt_mask], gt_occ.reshape(-1)[occ_gt_mask].reshape(-1, 1)], axis=1)[:, [2,1,0,3]]  # zyx cls
#     # gt_visible_save = np.concatenate([coordinates_3D_f[occ_gt_mask&visible_mask], gt_occ.reshape(-1)[occ_gt_mask&visible_mask].reshape(-1, 1)], axis=1)[:, [2,1,0,3]]  # zyx cls
    
#     scene_token = img_metas.data[0][0]['scene_token']
#     lidar_token = img_metas.data[0][0]['lidar_token']
#     save_path = osp.join(path, scene_token, lidar_token)
#     if not osp.exists(save_path):
#         os.makedirs(save_path)
#     save_pred_f_path = osp.join(save_path, 'pred_f.npy')
#     save_pred_c_path = osp.join(save_path, 'pred_c.npy')
#     # save_pred_f_v_path = osp.join(save_path, 'pred_f_visible.npy')
#     save_gt_path = osp.join(save_path, 'gt.npy')
#     # save_gt_v_path = osp.join(save_path, 'gt_visible.npy')
#     np.save(save_pred_f_path, pred_f_save)
#     np.save(save_pred_c_path, pred_c_save)
#     # np.save(save_pred_f_v_path, pred_f_visible_save)
#     np.save(save_gt_path, gt_save)
#     # np.save(save_gt_v_path, gt_visible_save)


import torch.nn.functional as F
import torch
import numpy as np
from os import path as osp
import os
import cv2
import open3d as o3d


def save_occ(pred_c, pred_f, img_metas, path, visible_mask=None, gt_occ=None, free_id=0, thres_low=0.4, thres_high=0.99):
    """
    保存预测结果，并提取 img_metas 中的图像和点云信息进行保存。
    """
    # 处理预测结果
    pred_f = F.softmax(pred_f, dim=1)
    pred_f = pred_f[0].cpu().numpy()  # C W H D
    pred_c = F.softmax(pred_c, dim=1)
    pred_c = pred_c[0].cpu().numpy()  # C W H D
    gt_occ = gt_occ.data[0][0].cpu().numpy()  # W H D
    gt_occ[gt_occ == 255] = 0

    _, W, H, D = pred_f.shape
    coordinates_3D_f = np.stack(
        np.meshgrid(np.arange(W), np.arange(H), np.arange(D), indexing="ij"), axis=-1
    ).reshape(-1, 3)  # (W*H*D, 3)
    _, W, H, D = pred_c.shape
    coordinates_3D_c = np.stack(
        np.meshgrid(np.arange(W), np.arange(H), np.arange(D), indexing="ij"), axis=-1
    ).reshape(-1, 3)  # (W*H*D, 3)
    pred_f = np.argmax(pred_f, axis=0)  # (W, H, D)
    pred_c = np.argmax(pred_c, axis=0)  # (W, H, D)
    occ_pred_f_mask = (pred_f.reshape(-1)) != free_id
    occ_pred_c_mask = (pred_c.reshape(-1)) != free_id
    occ_gt_mask = (gt_occ.reshape(-1)) != free_id
    pred_f_save = np.concatenate(
        [coordinates_3D_f[occ_pred_f_mask], pred_f.reshape(-1)[occ_pred_f_mask].reshape(-1, 1)], axis=1
    )[:, [2, 1, 0, 3]]  # zyx cls
    pred_c_save = np.concatenate(
        [coordinates_3D_c[occ_pred_c_mask], pred_c.reshape(-1)[occ_pred_c_mask].reshape(-1, 1)], axis=1
    )[:, [2, 1, 0, 3]]  # zyx cls
    gt_save = np.concatenate(
        [coordinates_3D_f[occ_gt_mask], gt_occ.reshape(-1)[occ_gt_mask].reshape(-1, 1)], axis=1
    )[:, [2, 1, 0, 3]]  # zyx cls

    # 提取元数据信息
    scene_token = img_metas.data[0][0].get("scene_token", "default_scene")
    lidar_token = img_metas.data[0][0].get("lidar_token", "default_lidar")
    save_path = osp.join(path, scene_token, lidar_token)
    if not osp.exists(save_path):
        os.makedirs(save_path)

    # 保存预测结果
    save_pred_f_path = osp.join(save_path, "pred_f.npy")
    save_pred_c_path = osp.join(save_path, "pred_c.npy")
    save_gt_path = osp.join(save_path, "gt.npy")
    np.save(save_pred_f_path, pred_f_save)
    np.save(save_pred_c_path, pred_c_save)
    np.save(save_gt_path, gt_save)
    print("Debug: img_metas.data:")
    print(type(img_metas.data))  # 输出数据类型
    print(img_metas.data)        # 查看内容
    # 提取并保存图像和点云
    if "image_paths" in img_metas.data[0][0]:
        image_paths = img_metas.data[0][0]["image_paths"]  # 图像文件路径列表
        for i, img_path in enumerate(image_paths):
            if osp.exists(img_path):
                img = cv2.imread(img_path)  # 读取图像
                if img is not None:
                    save_img_path = osp.join(save_path, f"image_{i}.png")  # 保存图像路径
                    cv2.imwrite(save_img_path, img)  # 保存图像
                    print(f"Saved image: {save_img_path}")
                else:
                    print(f"Warning: Could not read image from {img_path}")
            else:
                print(f"Warning: Image path does not exist - {img_path}")

    if "point_cloud_path" in img_metas.data[0][0]:
        point_cloud_path = img_metas.data[0][0]["point_cloud_path"]  # 点云文件路径
        if osp.exists(point_cloud_path):
            try:
                # 读取点云文件（假设为 .pcd 或 .ply 格式）
                pcd = o3d.io.read_point_cloud(point_cloud_path)
                save_pcd_path = osp.join(save_path, "point_cloud.ply")  # 保存点云路径
                o3d.io.write_point_cloud(save_pcd_path, pcd)  # 保存点云
                print(f"Saved point cloud: {save_pcd_path}")
            except Exception as e:
                print(f"Error: Could not read point cloud from {point_cloud_path}. Exception: {e}")
        else:
            print(f"Warning: Point cloud path does not exist - {point_cloud_path}")
