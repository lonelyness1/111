from .addfuse import AddFuser
from .visfuse import VisFuser
from .convfuse import ConvFuser
from .deepfuse import DeepFuser
