from .train import custom_train_model
from .mmdet_train import custom_train_detector
# from .test import custom_multi_gpu_test